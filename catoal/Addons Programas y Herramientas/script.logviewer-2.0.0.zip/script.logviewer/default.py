# -*- coding: utf-8 -*-

from resources.lib.navigation import run

run()
