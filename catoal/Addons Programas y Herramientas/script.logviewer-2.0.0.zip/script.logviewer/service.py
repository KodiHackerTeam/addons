# -*- coding: utf-8 -*-

from resources.lib.service import run

run()
