import urllib, urllib2,re

import urlparse
import xbmcgui
import xbmcplugin
import xbmcaddon
import os
import sys

from urllib2 import Request, urlopen, URLError, HTTPError
import requests

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)


def build_url(query):
    return base_url + '?' + urllib.urlencode(query)




def addMenuitem(url, li, folder):
    return xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=folder)


def endMenu():
    xbmcplugin.endOfDirectory(addon_handle)

def read(url):
    opener = urllib2.build_opener()
    opener.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.71 Safari/537.36')]
    response = opener.open(url)
    data = response.read()

    return data


def menu_ppal():
    duration = 17500
    dialog = xbmcgui.Dialog()
    dialog.notification("Fusion Request", 'Diviertete con Fusion Request el mejor Contenido Digital',
                        xbmcgui.NOTIFICATION_INFO, duration, False)
    fanart = 'https://i.imgur.com/gFdafKX.png'

    url = build_url({'mode': 'Novelas'})
    li = xbmcgui.ListItem('[COLOR yellow][B]Novelas[/B][/COLOR]',
                          iconImage='http://www.novelashdgratis.cc/img/logo.gif',
                          thumbnailImage='https://i.imgur.com/kZYkrHG.png')
    li.setInfo("video",
               {"Plot": '[COLOR skyblue][B]Reproduce el Mejor contenidoen la Web de Novelas en tu Idioma[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)

    url = build_url({'mode': 'search', 'site': 'youtube'})
    li = xbmcgui.ListItem('[COLOR yellow][B]Buscador de Youtube[/B][/COLOR]',
                          iconImage='http://sm.pcmag.com/t/pcmag_latam/photo/default/original_z8cw.640.jpg',
                          thumbnailImage='https://i.imgur.com/9tpR9nJ.png')
    li.setInfo("video",
               {"Plot": '[COLOR skyblue][B]Encuentra tus Videos Favoritos con el Buscador de Youtube[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)

    url = build_url({'mode': 'karaoke'})
    li = xbmcgui.ListItem('[COLOR yellow][B]Karaoke[/B][/COLOR]',
                          iconImage='https://i.pinimg.com/736x/6d/4e/d9/6d4ed9bda988e53269d0e925a259b612--karaoke-logos.jpg',
                          thumbnailImage='https://i.imgur.com/ClHBpMr.png')
    li.setInfo("video", {"Plot": '[COLOR yellow][B]Coleccion Selecta de Karaokes[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)

    url = build_url({'mode': 'plus01'})
    li = xbmcgui.ListItem('[COLOR yellow][B]PelisPlus[/B][/COLOR]',
                          iconImage='https://scontent-dft4-2.xx.fbcdn.net/v/t1.0-9/17634804_516923798698228_6361457002969571867_n.jpg?oh=9be6c309ab24227711b52e965207b877&oe=5A7DC18C',
                          thumbnailImage='https://i.imgur.com/UNQlcB0.png')
    li.setInfo("video", {
        "Plot": '[COLOR skyblue][B]Pelis Plus Contenido de Estrenos de Peliculas y Series de lo Mejor en la Web en tu Idioma[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)

    url = build_url({'mode': 'ultra'})
    li = xbmcgui.ListItem('[COLOR yellow][B]PelisUltra[/B][/COLOR]',
                          iconImage='http://www.pelisultra.com/wp-content/uploads/2017/03/logoultra2-1.png',
                          thumbnailImage='https://i.imgur.com/wDGkRUS.png')
    li.setInfo("video", {"Plot": '[COLOR yellow][B]Pelis Ultra Contenido de Estrenos de Peliculas[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)

    url = build_url({'mode': '0'})
    thumbnail = 'https://i.imgur.com/VMn38gW.png'
    li = xbmcgui.ListItem('[COLOR yellow][B]AnimeYT[/B][/COLOR]', iconImage=thumbnail, thumbnailImage=thumbnail)
    li.setInfo("video", {"Plot": '[COLOR skyblue][B]Aqui encontraras tus Animes Favoritos[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)

    url = build_url({'mode': 'blanco'})
    thumbnail = 'https://i.imgur.com/hCf4K9M.png'
    li = xbmcgui.ListItem('[COLOR yellow][B]Series Blanco[/B][/COLOR]', iconImage=thumbnail, thumbnailImage=thumbnail)
    li.setInfo("video", {"Plot": '[COLOR skyblue][B]Aqui encontraras tus Series Favoritas[/B][/COLOR]'})
    li.setProperty('fanart_image', fanart)
    addMenuitem(url, li, True)

    xbmcplugin.endOfDirectory(addon_handle)