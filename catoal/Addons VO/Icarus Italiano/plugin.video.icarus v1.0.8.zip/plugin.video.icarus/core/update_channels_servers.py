# -*- coding: utf-8 -*-

import glob
from threading import Thread

from core import channeltools, filetools, servertools
from platformcode import config


# Procedures
def update_channels():
    channels_path = filetools.join(config.get_runtime_path(), "channels", '*.json')

    channel_files = sorted(glob.glob(channels_path))

    for channel in channel_files:
        basename_without_extension = filetools.basename(channel)[:-5]
        channel_parameters = channeltools.get_channel_parameters(basename_without_extension)

        # Delete inactive channel
        if not channel_parameters["active"]:
            filetools.remove(channel[:-5] + '.py')
            filetools.remove(channel)


def update_servers():
    servers_path = filetools.join(config.get_runtime_path(), "servers", '*.json')

    server_files = sorted(glob.glob(servers_path))

    for server in server_files:
        basename_without_extension = filetools.basename(server)[:-5]
        server_parameters = servertools.get_server_parameters(basename_without_extension)

        # Delete inactive server
        if not server_parameters["active"]:
            filetools.remove(server[:-5] + '.py')
            filetools.remove(server)


# Run
Thread(target=update_channels).start()
Thread(target=update_servers).start()
