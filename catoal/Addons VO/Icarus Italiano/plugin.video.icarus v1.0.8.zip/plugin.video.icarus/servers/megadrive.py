# -*- coding: utf-8 -*-
# Icarus Community Edition - Kodi Addon
# by DrZ3r0

from core import httptools
from core import scrapertools
from platformcode import logger, config


def test_video_exists(page_url):
    logger.info("(page_url='%s')" % page_url)

    data = httptools.downloadpage(page_url).data

    if "File was deleted" in data:
        return False, config.get_localized_string(70449) % "Megadrive"

    return True, ""


# Returns an array of possible video url's from the page_url
def get_video_url(page_url, premium=False, user="", password="", video_password=""):
    logger.info("[megadrive.py] get_video_url(page_url='%s')" % page_url)
    video_urls = []

    data = httptools.downloadpage(page_url).data

    video_url = scrapertools.find_single_match(data, r"<source data-fluid-hd src='([^']+)")
    video_urls.append(["[megadrive]", video_url])

    for video_url in video_urls:
        logger.info("[megadrive.py] %s - %s" % (video_url[0], video_url[1]))

    return video_urls
