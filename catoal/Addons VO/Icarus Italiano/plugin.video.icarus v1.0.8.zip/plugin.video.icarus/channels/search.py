# -*- coding: utf-8 -*-
# Icarus Community Edition - Kodi Addon
# ------------------------------------------------------------
# Icarus  - XBMC Plugin
# https://alfa-addon.com/categories/icarus-addon.50/
# ------------------------------------------------------------
import Queue
import glob
import os
import re
import threading
import time
import urllib
from threading import Thread

from core import channeltools
from core.item import Item
from lib.fuzzywuzzy import fuzz
from platformcode import config, logger, platformtools

TIMEOUT_TOTAL = config.get_setting("timeout", default=90)
MAX_THREADS = config.get_setting("maxthreads", default=24)

__channel__ = "search"


def mainlist(item, preferred_thumbnail="squares"):
    logger.info(" mainlist")

    context = [{"title": config.get_localized_string(60412),
                "action": "settingCanal",
                "channel": item.channel}]
    itemlist = [
        Item(channel=item.channel,
             context=context,
             action="search",
             extra="movie",
             thumbnail="http://i.imgur.com/pE5WSZp.png",
             title=config.get_localized_string(60413)),
        Item(channel=item.channel,
             context=context,
             action="search",
             extra="tvshow",
             thumbnail="http://i.imgur.com/pE5WSZp.png",
             title=config.get_localized_string(60414)),
        Item(channel=item.channel,
             thumbnail="http://i.imgur.com/pE5WSZp.png",
             action="settings",
             title=config.get_localized_string(60415))
    ]

    saved_searches_list = get_saved_searches()

    context2 = context[:]
    context2.append({"title": config.get_localized_string(60416),
                     "action": "clear_saved_searches",
                     "channel": item.channel})
    for saved_search_text in saved_searches_list:
        itemlist.append(
            Item(channel=item.channel, action="do_search", title=' "' + urllib.unquote_plus(saved_search_text.split('{}')[0]) + '"',
                 extra=saved_search_text, context=context2, category=saved_search_text))

    if len(saved_searches_list) > 0:
        itemlist.append(
            Item(channel=item.channel,
                 action="clear_saved_searches",
                 thumbnail="http://i.imgur.com/pE5WSZp.png",
                 title=config.get_localized_string(60417)))

    return itemlist


def opciones(item):
    itemlist = [Item(channel=item.channel, action="settingCanal", title=config.get_localized_string(60418)),
                Item(channel=item.channel, action="clear_saved_searches", title=config.get_localized_string(60419)),
                Item(channel=item.channel, action="settings", title=config.get_localized_string(60420))]
    return itemlist


def settings(item):
    return platformtools.show_channel_settings()


def settingCanal(item):
    channels_path = os.path.join(config.get_runtime_path(), "channels", '*.json')
    channel_language = config.get_setting("channel_language")

    if channel_language == "":
        channel_language = "all"

    list_controls = []
    for infile in sorted(glob.glob(channels_path)):
        channel_name = os.path.basename(infile)[:-5]
        channel_parameters = channeltools.get_channel_parameters(channel_name)

        # Do not include inactive channel
        if channel_parameters["active"] != True:
            continue

        # Do not include adult channel if adult section is not selected
        if channel_parameters["adult"] == True and config.get_setting("adult_mode") == False:
            continue

        # Do not include channel if filtered by language
        if channel_language != "all" and channel_parameters["language"] != channel_language:
            continue

        # Do not include channel if not "include_in_global_search"
        include = channel_parameters["include_in_global_search"]
        if include not in ["", True]:
            continue
        else:
            # The stored value is searched in the channel configuration
            include_in_global_search = config.get_setting("include_in_global_search", channel_name)

        # Set the channel True if the configuration is missed 
        if include_in_global_search == "":
            include_in_global_search = True

        control = {'id': channel_name,
                   'type': "bool",
                   'label': channel_parameters["title"],
                   'default': include_in_global_search,
                   'enabled': True,
                   'visible': True}

        list_controls.append(control)

    return platformtools.show_channel_settings(list_controls=list_controls,
                                               caption=config.get_localized_string(60421),
                                               callback="save_settings", item=item)

def setting_channel(item):
    channels_path = os.path.join(config.get_runtime_path(), "channels", '*.json')
    channel_language = config.get_setting("channel_language", default="all")

    list_controls = []
    for infile in sorted(glob.glob(channels_path)):
        channel_name = os.path.basename(infile)[:-5]
        channel_parameters = channeltools.get_channel_parameters(channel_name)

        # No incluir si es un canal inactivo
        if not channel_parameters["active"]:
            continue

        # No incluir si es un canal para adultos, y el modo adulto está desactivado
        if channel_parameters["adult"] and config.get_setting("adult_mode") == 0:
            continue

        # No incluir si el canal es en un idioma filtrado
        if channel_language != "all" and channel_language not in channel_parameters["language"] \
                and "*" not in channel_parameters["language"]:
            continue

        # No incluir si en la configuracion del canal no existe "include_in_global_search"
        include_in_global_search = channel_parameters["include_in_global_search"]

        if not include_in_global_search:
            continue
        else:
            # Se busca en la configuración del canal el valor guardado
            include_in_global_search = config.get_setting("include_in_global_search", channel_name)

        control = {'id': channel_name,
                   'type': "bool",
                   'label': channel_parameters["title"],
                   'default': include_in_global_search,
                   'enabled': True,
                   'visible': True}

        list_controls.append(control)

    if config.get_setting("custom_button_value", item.channel):
        custom_button_label = config.get_localized_string(59992)
    else:
        custom_button_label = config.get_localized_string(59991)

    return platformtools.show_channel_settings(list_controls=list_controls,
                                               caption=config.get_localized_string(59990),
                                               callback="save_settings", item=item,
                                               custom_button={'visible': True,
                                                              'function': "cb_custom_button",
                                                              'close': False,
                                                              'label': custom_button_label})

def save_settings(item, dict_values):
    for v in dict_values:
        config.set_setting("include_in_global_search", dict_values[v], v)


def search(item, tecleado):
    logger.info(" search")

    item.extra = tecleado + '{}' + item.extra

    if tecleado != "":
        save_search(item.extra)

    return do_search(item)


def channel_search(queue, channel_parameters, category, tecleado):
    try:
        search_results = []

        title_search = urllib.unquote_plus(tecleado)

        exec "from channels import " + channel_parameters["channel"] + " as module"
        mainlist = module.mainlist(Item(channel=channel_parameters["channel"]))

        for item in mainlist:
            if item.action != "search" or category and item.extra != category:
                continue

            for res_item in module.search(item.clone(), tecleado):
                title = res_item.fulltitle

                # Clean up a bit the returned title to improve the fuzzy matching
                title = re.sub(r'\(.*\)', '', title)  # Anything within ()
                title = re.sub(r'\[.*\]', '', title)  # Anything within []

                # Check if the found title fuzzy matches the searched one
                if fuzz.WRatio(title_search, title) > 85:
                    res_item.title = "[COLOR azure]" + res_item.title + "[/COLOR][COLOR orange] su [/COLOR][COLOR green]" + channel_parameters["title"] + "[/COLOR]"
                    search_results.append(res_item)

        queue.put(search_results)

    except:
        logger.error("No se puede buscar en: " + channel_parameters["title"])
        import traceback
        logger.error(traceback.format_exc())


# This is the search function
def do_search(item):
    logger.info(" do_search")

    if '{}' in item.extra:
        tecleado, category = item.extra.split('{}')
    else:
        tecleado = item.extra
        category = ""

    itemlist = []

    channels_path = os.path.join(config.get_runtime_path(), "channels", '*.json')
    logger.info(" channels_path=" + channels_path)

    channel_language = config.get_setting("channel_language")
    logger.info(" channel_language=" + channel_language)
    if channel_language == "":
        channel_language = "all"
        logger.info(" channel_language=" + channel_language)

    progreso = platformtools.dialog_progress_bg(config.get_localized_string(60421) + urllib.unquote_plus(tecleado), "")
    channel_files = sorted(glob.glob(channels_path))

    number_of_channels = 0
    completed_channels = 0
    search_results = Queue.Queue()

    start_time = int(time.time())

    for infile in channel_files:

        basename_without_extension = os.path.basename(infile)[:-5]

        channel_parameters = channeltools.get_channel_parameters(basename_without_extension)

        # Ignore inactive channel
        if channel_parameters["active"] != True:
            continue

        # In case of search by categories
        if category and category not in channel_parameters["categories"]:
            continue

        # Ignore channel filtered by language
        if channel_language != "all" and channel_parameters["language"] != channel_language:
            continue

        # Ignore channel not configured in global search
        include_in_global_search = channel_parameters["include_in_global_search"]
        if include_in_global_search == True:
            # Search in the channel configuration
            include_in_global_search = config.get_setting("include_in_global_search", basename_without_extension)
        if include_in_global_search == False:
            continue

        t = Thread(target=channel_search, args=[search_results, channel_parameters, category, tecleado])
        t.setDaemon(True)
        t.start()
        number_of_channels += 1

        while threading.active_count() >= MAX_THREADS:
            delta_time = int(time.time()) - start_time
            if len(itemlist) <= 0:
                timeout = None  # No result so far,lets the thread to continue working until a result is returned
            elif delta_time >= TIMEOUT_TOTAL:
                progreso.close()
                itemlist = sorted(itemlist, key=lambda item: item.fulltitle)
                return itemlist
            else:
                timeout = TIMEOUT_TOTAL - delta_time  # Still time to gather other results

            progreso.update(completed_channels * 100 / number_of_channels)

            try:
                itemlist.extend(search_results.get(timeout=timeout))
                completed_channels += 1
            except:
                progreso.close()
                itemlist = sorted(itemlist, key=lambda item: item.fulltitle)
                return itemlist

    while completed_channels < number_of_channels:

        delta_time = int(time.time()) - start_time
        if len(itemlist) <= 0:
            timeout = None  # No result so far,lets the thread to continue working until a result is returned
        elif delta_time >= TIMEOUT_TOTAL:
            break  # At least a result matching the searched title has been found, lets stop the search
        else:
            timeout = TIMEOUT_TOTAL - delta_time  # Still time to gather other results

        progreso.update(completed_channels * 100 / number_of_channels)

        try:
            itemlist.extend(search_results.get(timeout=timeout))
            completed_channels += 1
        except:
            # Expired timeout raise an exception
            break

    progreso.close()

    itemlist = sorted(itemlist, key=lambda item: item.fulltitle)

    return itemlist


def save_search(text):
    saved_searches_limit = int((10, 20, 30, 40)[int(config.get_setting("saved_searches_limit", __channel__))])

    current_saved_searches_list = config.get_setting("saved_searches_list", __channel__)
    if current_saved_searches_list is None:
        saved_searches_list = []
    else:
        saved_searches_list = list(current_saved_searches_list)

    if text in saved_searches_list:
        saved_searches_list.remove(text)

    saved_searches_list.insert(0, text)

    config.set_setting("saved_searches_list", saved_searches_list[:saved_searches_limit], __channel__)


def clear_saved_searches(item):
    config.set_setting("saved_searches_list", list(), __channel__)
    platformtools.dialog_ok(config.get_localized_string(60423), config.get_localized_string(60424))


def get_saved_searches():
    current_saved_searches_list = config.get_setting("saved_searches_list", __channel__)
    if current_saved_searches_list is None:
        saved_searches_list = []
    else:
        saved_searches_list = list(current_saved_searches_list)
    
    return saved_searches_list
