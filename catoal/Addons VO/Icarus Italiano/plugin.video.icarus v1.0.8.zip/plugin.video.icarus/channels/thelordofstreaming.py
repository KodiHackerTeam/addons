# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# Icarus - XBMC Plugin
# Canale per Thelordofstreaming
# https://alfa-addon.com/categories/icarus-addon.50/
# ----------------------------------------------------------

import re

from platformcode import logger, config
from core import servertools, httptools, scrapertools
from core.item import Item
from core.tmdb import infoIca



host = "http://www.thelordofstreaming.it"

PERPAGE = 12

# ----------------------------------------------------------------------------------------------------------------
def mainlist(item):
    logger.info("Icarus [thelordofstreaming.py]==> Mainlist")
    itemlist = [Item(channel=item.channel,
                     action="movies",
                     title="Film",
                     extra="movie",
                     text_color="azure",
                     url="%s/category/movie/" % host,
                     thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png"),
                Item(channel=item.channel,
                     action="movies",
                     title="Wrestling",
                     text_color="azure",
                     url="%s/category/wrestling/" % host,
                     thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png"),
                Item(channel=item.channel,
                     action="tvseries",
                     title="Serie TV",
                     extra="tvshow",
                     text_color="azure",
                     url="%s/serie-tv/" % host,
                     thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png"),
                Item(channel=item.channel,
                     title="[COLOR yellow]Cerca...[/COLOR]",
                     action="search",
                     extra="movie",
                     thumbnail="http://dc467.4shared.com/img/fEbJqOum/s7/13feaf0c8c0/Search"),
                Item(channel=item.channel,
                     title="[COLOR yellow]Cerca Serie TV...[/COLOR]",
                     action="search",
                     extra="tvshow",
                     thumbnail="http://dc467.4shared.com/img/fEbJqOum/s7/13feaf0c8c0/Search")]

    return itemlist

# ================================================================================================================

# ----------------------------------------------------------------------------------------------------------------
def movies(item):
    logger.info("Icarus [thelordofstreaming.py]==> Movies")
    itemlist = []

    data = httptools.downloadpage(item.url).data
    blocco = scrapertools.find_single_match(data, r'<nav id="nav-above">(.*?)</section><!-- #primary -->')
    patron = r'<article id="post-\d+"(.*?)</article>'
    matches = re.findall(patron, blocco, re.DOTALL)

    for match in matches:
        scrapedtitle = re.findall(r'<h1 class="entry-title">[^>]+>([^<]+)</a></h1>', match, re.DOTALL)[0]
        scrapedurl = re.findall(r'<h1 class="entry-title"><a href="([^"]+)"[^>]+>[^<]+</a></h1>', match, re.DOTALL)[0]
        scrapedthumbnail = re.findall(r'<img class="[^"]+"\s*src="([^"]+)"[^>]+>', match, re.DOTALL)[0]
        urls = scrapertools.find_single_match(match, r'<p>(.*?)</p>')

        itemlist.append(infoIca(
            Item(channel=item.channel,
                 action="findvideos",
                 text_color="azure",
                 contentType="movie",
                 title=scrapedtitle,
                 fulltitle=scrapedtitle,
                 url=scrapedurl,
                 extra=urls,
                 thumbnail=scrapedthumbnail,
                 folder=True), tipo="movie"))

    patronvideos = r'<div class="nav-previous"><a href="([^"]+)"[^>]*><span class="meta-nav">&larr;</span> Articoli più vecchi</a></div>'
    matches = re.compile(patronvideos, re.DOTALL).findall(data)

    if len(matches) > 0:
        scrapedurl = matches[0]
        itemlist.append(
            Item(channel=item.channel,
                 action="movies",
                 title="[COLOR lightgreen]" + config.get_localized_string(30992) + "[/COLOR]",
                 url=scrapedurl,
                 thumbnail="http://2.bp.blogspot.com/-fE9tzwmjaeQ/UcM2apxDtjI/AAAAAAAAeeg/WKSGM2TADLM/s1600/pager+old.png",
                 folder=True))

    return itemlist

# ================================================================================================================

# ----------------------------------------------------------------------------------------------------------------
def tvseries(item):
    logger.info("Icarus [thelordofstreaming.py]==> TVSeries")
    itemlist = []

    p = 1
    if '{}' in item.url:
        item.url, p = item.url.split('{}')
        p = int(p)

    data = httptools.downloadpage(item.url).data
    blocco = scrapertools.find_single_match(data, r'<div class="entry-content">\s*<ul>(.*?)</ul>')
    patron = r'<li><a href="([^"]+)"[^>]*>([^<]+)</a></li>'
    matches = re.findall(patron, blocco, re.DOTALL)

    for i, (scrapedurl, scrapedtitle) in enumerate(matches):
        if (p - 1) * PERPAGE > i: continue
        if i >= p * PERPAGE: break
        scrapedtitle = scrapertools.decodeHtmlentities(scrapedtitle).strip()
        itemlist.append(infoIca(
            Item(channel=item.channel,
                 action="episodios",
                 text_color="azure",
                 contentType="tv",
                 title=scrapedtitle,
                 fulltitle=scrapedtitle,
                 url=scrapedurl,
                 show=scrapedtitle,
                 folder=True), tipo='tv'))

    if len(matches) >= p * PERPAGE:
        scrapedurl = item.url + '{}' + str(p + 1)
        itemlist.append(
            Item(channel=item.channel,
                 extra=item.extra,
                 action="tvseries",
                 title="[COLOR lightgreen]" + config.get_localized_string(30992) + "[/COLOR]",
                 url=scrapedurl,
                 thumbnail="http://2.bp.blogspot.com/-fE9tzwmjaeQ/UcM2apxDtjI/AAAAAAAAeeg/WKSGM2TADLM/s1600/pager+old.png",
                 folder=True))


    return itemlist

# ================================================================================================================

# ----------------------------------------------------------------------------------------------------------------
def episodios(item):
    logger.info("Icarus [thelordofstreaming.py]==> episodios")
    itemlist = []

    data = httptools.downloadpage(item.url).data
    blocco = scrapertools.find_single_match(data, r'<div class="entry-content">(.*?)</div>')
    patron = r'(\d+\&\#215\;\d+)(.*?)(?:<br \/>|<span style="color: #\d+;"><em>FINE</em>)'
    matches = re.findall(patron, blocco, re.DOTALL)

    for scrapedtitle, scrapedlinks in matches:
        scrapedtitle = scrapertools.decodeHtmlentities(scrapedtitle).strip()
        itemlist.append(
            Item(channel=item.channel,
                 action="findvideos",
                 text_color="azure",
                 contentType="episode",
                 title=scrapedtitle,
                 fulltitle=scrapedtitle,
                 url=scrapedlinks,
                 extra="",
                 folder=True))

    if config.get_videolibrary_support() and len(itemlist) != 0:
        itemlist.append(
            Item(channel=item.channel,
                 title="[COLOR lightblue]%s[/COLOR]" % config.get_localized_string(30161),
                 url=item.url,
                 action="add_serie_to_library",
                 extra="episodios",
                 show=item.show))

    return itemlist

# ================================================================================================================

# ----------------------------------------------------------------------------------------------------------------
def findvideos(item):
    logger.info("Icarus [thelordofstreaming.py]==> Findvideos")

    if item.extra and item.extra != "page":
        itemlist = servertools.find_video_items(data=item.extra)
    elif item.extra and item.extra == "page":
        itemlist = servertools.find_video_items(data=httptools.downloadpage(item.url).data)
    else:
        itemlist = servertools.find_video_items(data=item.url)

    for videoitem in itemlist:
        server = re.sub(r'[-\[\]\s]+', '', videoitem.title)
        videoitem.text_color = "azure"
        videoitem.title = "".join(["[%s] " % color(server.capitalize(), 'orange'), item.title])
        videoitem.fulltitle = item.fulltitle
        videoitem.show = item.show
        videoitem.thumbnail = item.thumbnail
        videoitem.channel = item.channel
    return itemlist

# ================================================================================================================

def search(item, texto):
    logger.info("[thelordofstreaming.py] " + item.url + " search " + texto)
    item.url = host + "/?s=" + texto + "&submit=Cerca"
    try:
        if item.extra == "movie":
            return movies_src(item)
        if item.extra == "tvshow":
            return tvseries_src(item)
    # Continua la ricerca in caso di errore 
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []

def movies_src(item):
    logger.info("icarus.thelordofstreaming peliculas")
    itemlist = []

    # Carica la pagina 
    data = httptools.downloadpage(item.url).data

    # Estrae i contenuti 
    patron = '<h1 class="entry-title"><a href="([^"]+)" rel="bookmark">(.*?)</a></h1>'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for scrapedurl, scrapedtitle in matches:
        scrapedplot = ""
        scrapedthumbnail = ""
        scrapedtitle = scrapertools.decodeHtmlentities(scrapedtitle)

        itemlist.append(infoIca(
            Item(channel=item.channel,
                 action="findvideos",
                 contentType="movie",
                 title=scrapedtitle,
                 fulltitle=scrapedtitle,
                 url=scrapedurl,
                 thumbnail=scrapedthumbnail), tipo="movie"))

    return itemlist

def tvseries_src(item):
    logger.info("icarus.thelordofstreaming peliculas")
    itemlist = []

    # Carica la pagina 
    data = httptools.downloadpage(item.url).data

    # Estrae i contenuti 
    patron = '<h1 class="entry-title"><a href="([^"]+)" rel="bookmark">(.*?)</a></h1>'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for scrapedurl, scrapedtitle in matches:
        scrapedplot = ""
        scrapedthumbnail = ""
        scrapedtitle = scrapertools.decodeHtmlentities(scrapedtitle)

        itemlist.append(infoIca(
            Item(channel=item.channel,
                 action="episodios",
                 contentType="tv",
                 title=scrapedtitle,
                 fulltitle=scrapedtitle,
                 url=scrapedurl,
                 thumbnail=scrapedthumbnail), tipo="tv"))

    return itemlist

def color(text, color):
    return "[COLOR %s]%s[/COLOR]" % (color, text)

