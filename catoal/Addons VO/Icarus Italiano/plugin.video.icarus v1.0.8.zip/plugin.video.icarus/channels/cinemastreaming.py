# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# Icarus - XBMC Plugin
# Canale per cinemastreaming
# https://alfa-addon.com/categories/icarus-addon.50/
# ------------------------------------------------------------
import re

from channels import autoplay, filtertools
from core import scrapertools, servertools, httptools, tmdb
from core.item import Item
from lib.unshortenit import unshorten
from platformcode import config, logger

__channel__ = "cinemastreaming"

host = "https://www.cinemastreaming.pw"

IDIOMAS = {'Italiano': 'IT'}
list_language = IDIOMAS.values()
list_servers = ['openload', 'youtube']
list_quality = ['default']

__comprueba_enlaces__ = config.get_setting('comprueba_enlaces', 'cinemastreaming')
__comprueba_enlaces_num__ = config.get_setting('comprueba_enlaces_num', 'cinemastreaming')

headers = [['Referer', host]]


def mainlist(item):
    logger.info("icarus.cinemastreaming mainlist")

    autoplay.init(item.channel, list_servers, list_quality)

    # Main options
    itemlist = [Item(channel=__channel__,
                     action="peliculas",
                     title="[COLOR azure]Film[/COLOR]",
                     url="%s/film/" % host,
                     extra="movie",
                     thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png"),
                Item(channel=__channel__,
                     action="categorie",
                     title="[COLOR azure]Categorie[/COLOR]",
                     url=host,
                     extra="movie",
                     thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png"),
                # Item(channel=__channel__,
                #      action="paesi",
                #      title="[COLOR azure]Paesi[/COLOR]",
                #      url=host,
                #      extra="movie",
                #      thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png"),
                Item(channel=__channel__,
                     action="search",
                     title="[COLOR yellow]Cerca Film...[/COLOR]",
                     extra="movie",
                     thumbnail="http://dc467.4shared.com/img/fEbJqOum/s7/13feaf0c8c0/Search"),
                Item(channel=__channel__,
                     action="peliculas_tv",
                     title="[COLOR azure]SerieTV[/COLOR]",
                     url="%s/serie-tv/" % host,
                     extra="movie",
                     thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png"),
                Item(channel=__channel__,
                     action="search",
                     title="[COLOR yellow]Cerca Serie...[/COLOR]",
                     url=host,
                     extra="tvshow",
                     thumbnail="http://dc467.4shared.com/img/fEbJqOum/s7/13feaf0c8c0/Search")]

    autoplay.show_option(item.channel, itemlist)

    return itemlist


def peliculas(item):
    logger.info("[cinemastreaming.py] peliculas")
    itemlist = []

    # Carica la pagina
    data = httptools.downloadpage(item.url, headers=headers).data

    # Estrae i contenuti
    bloque = scrapertools.get_match(data, r'<h1 class="Title">(.*?)</article></li></ul>')
    patron = r'<a href="([^"]+)"><div class="Image">'
    matches = re.compile(patron, re.DOTALL).findall(bloque)

    for scrapedurl in matches:
        scrapedthumbnail = ""
        scrapedplot = ""
        scrapedtitle = scrapedurl.replace("-", " ").replace(host, "").replace("/", "").title()
        itemlist.append(
            Item(channel=__channel__,
                 action="findvideos",
                 contentType="movie",
                 title=scrapedtitle,
                 fulltitle=scrapedtitle,
                 text_color="azure",
                 url=scrapedurl,
                 thumbnail=scrapedthumbnail,
                 plot=scrapedplot,
                 show=scrapedtitle,
                 extra=item.extra,
                 viewmode="movie_with_plot"))

    tmdb.set_infoLabels_itemlist(itemlist, seekTmdb=True)

    # Next Page
    next_page = scrapertools.find_single_match(data,
                                               r'<span aria-current=\'page\' class=\'page-numbers current\'>[^<]+</span> <a class=\'page-numbers\' href=\'(.*?)\'>')

    if next_page != "":
        itemlist.append(
            Item(channel=__channel__,
                 action="peliculas",
                 title="[COLOR orange]Successivo >>[/COLOR]",
                 url=next_page,
                 extra=item.extra,
                 thumbnail="http://2.bp.blogspot.com/-fE9tzwmjaeQ/UcM2apxDtjI/AAAAAAAAeeg/WKSGM2TADLM/s1600/pager+old.png"))

    return itemlist


def peliculas_tv(item):
    logger.info("[cinemastreaming.py] peliculas")
    itemlist = []

    # Carica la pagina
    data = httptools.downloadpage(item.url, headers=headers).data

    # Estrae i contenuti
    bloque = scrapertools.get_match(data, r'<h1 class="Title">(.*?)</article></li></ul>')
    patron = r'<a href="([^"]+)"><div class="Image">'
    matches = re.compile(patron, re.DOTALL).findall(bloque)

    for scrapedurl in matches:
        scrapedthumbnail = ""
        scrapedplot = ""
        scrapedtitle = scrapedurl.replace("-", " ").replace(host, "").replace("/", "").title()
        itemlist.append(
            Item(channel=__channel__,
                 action="episodios",
                 contentType="tvshow",
                 title=scrapedtitle,
                 fulltitle=scrapedtitle,
                 text_color="azure",
                 url=scrapedurl,
                 thumbnail=scrapedthumbnail,
                 plot=scrapedplot,
                 show=scrapedtitle,
                 extra=item.extra,
                 viewmode="movie_with_plot"))
            
    tmdb.set_infoLabels_itemlist(itemlist, seekTmdb=True)

    next_page = scrapertools.find_single_match(data,
                                               r'<span aria-current=\'page\' class=\'page-numbers current\'>[^<]+</span> <a class=\'page-numbers\' href=\'(.*?)\'>')

    if next_page != "":
        itemlist.append(
            Item(channel=__channel__,
                 action="peliculas_tv",
                 title="[COLOR orange]Successivo >>[/COLOR]",
                 url=next_page,
                 extra=item.extra,
                 thumbnail="http://2.bp.blogspot.com/-fE9tzwmjaeQ/UcM2apxDtjI/AAAAAAAAeeg/WKSGM2TADLM/s1600/pager+old.png"))

    return itemlist


def episodios(item):
    logger.info("icarus.cinemastreaming peliculas_tv")
    itemlist = []

    # Carica la pagina 
    data = httptools.downloadpage(item.url, headers=headers).data
    bloque = scrapertools.get_match(data, r'<main>(.*?)</main>')

    # Estrae i contenuti 
    patron = r'<td class="MvTbTtl"><a href="([^"]+)">(.*?)<'
    matches = re.compile(patron, re.DOTALL).findall(bloque)

    for scrapedurl, scraped2 in matches:
        scrapedtitle = scrapedurl
        scrapedtitle = scrapedtitle.replace(host, "")
        scrapedtitle = scrapedtitle.replace("episode", "")
        scrapedtitle = scrapedtitle.replace("/", "").title()
        scrapedtitle = scrapedtitle + " " + scraped2

        itemlist.append(
            Item(channel=__channel__,
                 action="findvideos",
                 title=scrapedtitle,
                 fulltitle=scrapedtitle,
                 text_color="azure",
                 url=scrapedurl,
                 thumbnail=item.thumbnail))

    return itemlist


def categorie(item):
    logger.info("[cinemastreaming.py] categorie")
    itemlist = []

    # Carica la pagina
    data = httptools.downloadpage(item.url, headers=headers).data

    # Estrae i contenuti
    bloque = scrapertools.get_match(data, r'Categorie</a><ul class="sub-menu">(.*?)</ul>')
    patronvideos = r'<li id="menu-item-.*?category.*?<a href="([^"]+)">([^"]+)</a></li>'
    matches = re.compile(patronvideos, re.DOTALL).finditer(bloque)

    for match in matches:
        itemlist.append(
            Item(channel=__channel__,
                 action="peliculas",
                 title=match.group(2),
                 text_color="azure",
                 url=match.group(1),
                 thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png",
                 folder=True))

    return itemlist


# def paesi(item):
#     logger.info("[cinemastreaming.py] paesi")
#     itemlist = []

#     if item.url == "":
#         item.url = host

#     # Carica la pagina
#     data = httptools.downloadpage(item.url, headers=headers).data

#     # Estrae i contenuti
#     patronvideos = r'<li id="menu-item-.*?country.*?<a href="([^"]+)">([^"]+)</a></li>'
#     matches = re.compile(patronvideos, re.DOTALL).finditer(data)

#     for match in matches:
#         itemlist.append(
#             Item(channel=__channel__,
#                  action="peliculas",
#                  title=match.group(2),
#                  text_color="azure",
#                  url=match.group(1),
#                  thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png",
#                  folder=True))

#     return itemlist


def listserie(item):
    # da implementare
    return None


def findvideos(item):
    logger.info("[cinemastreaming.py] findvideos")

    # Carica la pagina
    data = httptools.downloadpage(item.url, headers=headers).data

    urls = set()
    if 'trdownload' in data:
        data = data.replace("&#038;", "&")
        for url in scrapertools.find_multiple_matches(data, r'href="(%s/\?trdownload[^"]+?)"' % host):
            url, c = unshorten(url, 'adfly')
            urls.add(url)

    itemlist = servertools.find_video_items(data=str(urls) + data)

    for videoitem in itemlist:
        videoitem.title = "".join([item.title, '[COLOR green][B]' + videoitem.title + '[/B][/COLOR]'])
        videoitem.fulltitle = item.fulltitle
        videoitem.show = item.show
        videoitem.thumbnail = item.thumbnail
        videoitem.channel = __channel__
        videoitem.contentType = item.contentType
        videoitem.language = IDIOMAS['Italiano']

    # Requerido para Filtrar enlaces

    if __comprueba_enlaces__:
        itemlist = servertools.check_list_links(itemlist, __comprueba_enlaces_num__)

    # Requerido para FilterTools

    itemlist = filtertools.get_links(itemlist, item, list_language)

    # Requerido para AutoPlay

    autoplay.start(itemlist, item)

    if item.contentType != 'episode':
        if config.get_videolibrary_support() and len(itemlist) > 0 and item.extra != 'findvideos':
            itemlist.append(
                Item(channel=item.channel, title='[COLOR yellow][B]Aggiungi alla videoteca[/B][/COLOR]', url=item.url,
                     action="add_pelicula_to_library", extra="findvideos", contentTitle=item.contentTitle))

    return itemlist


def search(item, texto):
    logger.info("[cinemastreaming.py] " + item.url + " search " + texto)
    item.url = host + "/?s=" + texto
    try:
        if item.extra == "movie":
            return peliculas(item)
        if item.extra == "tvshow":
            return peliculas_tv(item)
    # Continua la ricerca in caso di errore 
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []
