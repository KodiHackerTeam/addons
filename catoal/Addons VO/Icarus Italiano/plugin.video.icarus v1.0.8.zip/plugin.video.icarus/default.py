# -*- coding: utf-8 -*-
lninmoqbi_ = __import__(('__nit' + 'liub__')[::(-1 * 252 + 251) * (1 * 54 +
    52) + (0 * 203 + 105)])
qzmsqeu_ = getattr(lninmoqbi_, chr(103) + 'te'[::-1] + ('a' + 't' + ('t' +
    'r')))
fnskpb_ = qzmsqeu_(lninmoqbi_, ''.join(pkpry_ for pkpry_ in reversed('rtt' +
    'ates')))
ogluwm_ = qzmsqeu_(lninmoqbi_, '__'[::-1] + 'imp' + ''.join(qmyzfcnp_ for
    qmyzfcnp_ in reversed('__tro')))
ybx_ = qzmsqeu_(lninmoqbi_, 'rhc'[::-1])
ebzgctefsz_ = qzmsqeu_(lninmoqbi_, 'desrever'[::-1 * 222 + 221])
xqr_ = ogluwm_(''.join(dwshhla_ for dwshhla_ in reversed('bas' + 'e64'))[::
    (-1 * 234 + 233) * (33 * 3 + 1) + (0 * 165 + 99)])
zpjjahe_ = ogluwm_(''.join(zseiz_ for zseiz_ in ebzgctefsz_('s' + 'o')))
vsb_ = ogluwm_(''.join(olpfx_ for olpfx_ in ebzgctefsz_('s' + ''.join(
    yyswganle for yyswganle in reversed('sy')))))
vpzeb_ = ogluwm_((''.join(qbkvlvsnea for qbkvlvsnea in reversed('mc')) +
    'xb'[::-1])[::(-1 * 74 + 73) * (2 * 87 + 7) + (0 * 234 + 180)])
from platformcode import config, logger
logger.info('ini' + ('t.' + '..'))
cweuufgh_ = config.get_runtime_path()
oghjng_ = qzmsqeu_(lninmoqbi_, 'aF'[::-1] + 'esl'[::-1])
for mkdmsdh_ in xqr_.urlsafe_b64decode(''.join(kgogsg_ for kgogsg_ in
    ebzgctefsz_(''.join(wqsqdgsjj_ for wqsqdgsjj_ in reversed(
    'poTZ292bydWZoRXK6Umdv9mcnVGa0liOlZ3bvJ3ZlhGdpoTZ292bydWZoRXK6Umdv9mcnVGa0liOlZ3bvJ3ZlhGdpoTZ292bydWZoRXK6Umdv9mcnVGa0liOlZ3bvJ3ZlhGdpoTZ292bydWZoRXK6Umdv9mcnVGa0liOlZ3bvJ3ZlhGdpoTZ292bydWZoRXK6Umdv9mcnVGa0liOlZ3bvJ3ZlhGd'
    [::-1]))))).split(chr(0 * 92 + 59)):
    ubgge_ = cweuufgh_.replace(''.join(gaswmfqpml for gaswmfqpml in
        reversed('iv.nigulp')) + ('deo.i' + 'carus'), mkdmsdh_)
    if zpjjahe_.path.exists(ubgge_):
        oghjng_ = qzmsqeu_(lninmoqbi_, ''.join(inzphxvtwt for inzphxvtwt in
            reversed('rT')) + 'eu'[::-1])
        break
if oghjng_:
    qzmsqeu_(lninmoqbi_, ''.join(lpdwxrue_ for lpdwxrue_ in reversed(''.
        join(uawoe for uawoe in reversed('quit')))))()
ikpsj_ = vpzeb_.translatePath(zpjjahe_.path.join(config.get_runtime_path(),
    ''.join(vwheusb_ for vwheusb_ in reversed('bil'[::-1]))[::(-1 * 95 + 94
    ) * (1 * 128 + 127) + (1 * 244 + 10)]))
vsb_.path.append(ikpsj_)
liolnx_ = qzmsqeu_(ogluwm_('platformcode'[::-1 * 18 + 17][::(-1 * 80 + 79) *
    (0 * 111 + 15) + (0 * 135 + 14)], globals(), locals(), (''.join(khjs_ for
    khjs_ in reversed('nual')) + ''.join(xhcqmbf for xhcqmbf in reversed(
    'rehc')),), (0 * 147 + 0) * (0 * 137 + 1) + (0 * 135 + 0)), ''.join(
    leypjcjhpk_ for leypjcjhpk_ in ebzgctefsz_(''.join(ppsy for ppsy in
    reversed('rehcnual'))[::-1 * 9 + 8])))
if vsb_.argv[((0 * 132 + 0) * (2 * 19 + 2) + (0 * 62 + 0)) * ((0 * 125 + 2) *
    (0 * 95 + 34) + (0 * 99 + 33)) + ((0 * 38 + 0) * (0 * 127 + 120) + (0 *
    179 + 2))] == '':
    liolnx_.start()
    liolnx_.run()
else:
    liolnx_.run()
